package bitcamp.travelmaker.dto;

import java.sql.Date;
import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

public class MemberDTO {
	private String M_Email;
	private String M_Nickname;
	private String A_Code;
	private String M_Pwd;
	private String M_Image;
	private Date M_Regdate;
	private String M_Gender;
	
	
	private CommonsMultipartFile file;
	public CommonsMultipartFile getFile() {
		return file;
	}
	public void setFile(CommonsMultipartFile file) {
		this.file = file;
	}
	
	public String getM_Email() {
		return M_Email;
	}
	public void setM_Email(String m_Email) {
		M_Email = m_Email;
	}
	public String getM_Nickname() {
		return M_Nickname;
	}
	public void setM_Nickname(String m_Nickname) {
		M_Nickname = m_Nickname;
	}
	public String getA_Code() {
		return A_Code;
	}
	public void setA_Code(String a_Code) {
		A_Code = a_Code;
	}
	public String getM_Pwd() {
		return M_Pwd;
	}
	public void setM_Pwd(String m_Pwd) {
		M_Pwd = m_Pwd;
	}
	public String getM_Image() {
		return M_Image;
	}
	public void setM_Image(String m_Image) {
		M_Image = m_Image;
	}
	public Date getM_Regdate() {
		return M_Regdate;
	}
	public void setM_Regdate(Date m_Regdate) {
		M_Regdate = m_Regdate;
	}
	public String getM_Gender() {
		return M_Gender;
	}
	public void setM_Gender(String m_Gender) {
		M_Gender = m_Gender;
	}
	@Override
	public String toString() {
		return "MemberDTO [M_Email=" + M_Email + ", M_Nickname=" + M_Nickname + ", A_Code=" + A_Code + ", M_Pwd="
				+ M_Pwd + ", M_Image=" + M_Image + ", M_Regdate=" + M_Regdate + ", M_Gender=" + M_Gender + ", file="
				+ file + "]";
	}
	
	
	

}
