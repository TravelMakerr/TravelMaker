package bitcamp.travelmaker.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import bitcamp.travelmaker.dao.MemberDAO;
import bitcamp.travelmaker.dto.MemberDTO;

@Service
public class JoinService {

	@Autowired
	private SqlSession sqlsession;
	
	@Transactional(rollbackFor={Exception.class})
	public int insertMember(MemberDTO memberdto) throws Exception{
		int result = 0;
		MemberDAO dao = sqlsession.getMapper(MemberDAO.class);
		result = dao.insertMember(memberdto);
		if(result>0) {
			dao.insertRoll(memberdto.getM_Email());
			
		}
		return result;
	}
//	
	public int idCheck(String M_Email){
		MemberDAO dao = sqlsession.getMapper(MemberDAO.class);
		int result = dao.idCheck(M_Email);
		return result;
	}
//	
//	public int loginCheck(String member_id, String member_pwd){
//		MemberDAO dao = sqlsession.getMapper(MemberDAO.class);
//		int result = dao.loginCheck(member_id, member_pwd);
//		return result;
//	}
}
