package bitcamp.travelmaker.dao;

import bitcamp.travelmaker.dto.MemberDTO;

public interface MemberDAO {

	
	public int insertMember(MemberDTO member);
	
	public int idCheck(String M_Email);
	
	public int insertRoll(String M_Email);
}
