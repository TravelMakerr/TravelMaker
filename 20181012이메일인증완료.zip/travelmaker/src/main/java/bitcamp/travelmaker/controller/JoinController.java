package bitcamp.travelmaker.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.View;

import bitcamp.travelmaker.dto.MemberDTO;
import bitcamp.travelmaker.service.JoinService;


@Controller
@RequestMapping("/joinus/")
public class JoinController {

/*	@Autowired
	private MemberDao memberdao;*/

	//비동기
	@Autowired
	private View jsonview;
//	
	@Autowired
	private JoinService service;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@RequestMapping(value="join.htm",method=RequestMethod.POST)
	public String join(HttpServletRequest request, MemberDTO memberdto) throws ClassNotFoundException, SQLException, IOException {
		
		CommonsMultipartFile file = memberdto.getFile();
		
		if (file != null && file.getSize() > 0) { // 업로드한 파일이 하나라도 있다면
				String fname = file.getOriginalFilename(); // 파일명 얻기
				String path = request.getServletContext().getRealPath("/member/image");
				String fullpath = path + "\\" + fname;

				System.out.println(fname + " / " + path + " / " + fullpath);
				memberdto.setM_Image(fname);
				if (!fname.equals("")) {
					// 서버에 파일 쓰기 작업
					FileOutputStream fs = new FileOutputStream(fullpath);
					fs.write(file.getBytes());
					fs.close();
				}
				 // 실 DB Insert 작업시 .. 파일명
			}
		
		int result = 0;
		String viewpage="redirect:/index.htm";
		
		memberdto.setM_Pwd(this.bCryptPasswordEncoder.encode(memberdto.getM_Pwd()));
		try{
			result = service.insertMember(memberdto);
			
		if(result > 0) {
			System.out.println("가입성공");
			viewpage = "redirect:/index.htm";
		}else {
			System.out.println("가입실패");
		}
		} catch (Exception e) {
			viewpage = "redirect:/index.htm";
		}
		
		return viewpage; //주의 (website/index.htm
		
	}
//	
//	//비동기 JSONVIEW
	@RequestMapping(value = "idcheck.htm")
	public View idCheck(@RequestParam("M_Email") String M_Email, Model model) {
		int result = service.idCheck(M_Email);
		if (result > 0) {
			System.out.println("아이디 중복");
			model.addAttribute("result", "fail");
		} else {
			System.out.println("아이디 사용가능");
			model.addAttribute("result", "success");
		}
		return jsonview; //{"result":"fail"}
	}
	/*
//	@RequestMapping(value="idcheck.htm")
//	public View idCheck(String userid , ModelMap map){
//		System.out.println("userid:" +userid);
//		String data="";
//		if(userid.equals("kglim")){
//			data ="success";
//		}else{
//			data = "fail";
//		}
//		map.addAttribute("userid", data);
//		return jsonview;
//	}
//	*/
}
